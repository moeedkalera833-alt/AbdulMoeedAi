package com.abdulmoeed.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_SPEECH = 10;
    private static final int REQ_AUDIO = 11;
    private TextView status;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean greetingStarted = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF101B32);
        getWindow().setNavigationBarColor(0xFF101B32);
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int r = tts.setLanguage(new Locale("ur", "PK"));
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(new Locale("en", "US"));
                }
                ttsReady = true;
                startGreetingWhenReady();
            }
        });

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 42, 28, 28);
        root.setBackgroundColor(0xFF101B32);

        TextView title = new TextView(this);
        title.setText("Abdul Moeed AI");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title, fullWidth(70));

        TextView subtitle = new TextView(this);
        subtitle.setText("آپ کا ذاتی اردو وائس اسسٹنٹ");
        subtitle.setTextColor(0xFFB6C9E4);
        subtitle.setTextSize(18);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, fullWidth(55));

        status = new TextView(this);
        status.setText("السلام علیکم! حکم دینے کے لیے مائیک بٹن دبائیں۔");
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(17);
        status.setGravity(Gravity.CENTER);
        status.setPadding(12, 25, 12, 25);
        root.addView(status, fullWidth(130));

        Button listen = button("🎙  بول کر حکم دیں");
        listen.setOnClickListener(v -> listen());
        root.addView(listen, fullWidth(64));

        Button access = button("موبائل کنٹرول کی اجازت کھولیں");
        access.setOnClickListener(v -> startActivity(new Intent("android.settings.ACCESSIBILITY_SETTINGS")));
        root.addView(access, fullWidth(58));

        Button help = button("مثالی احکامات");
        help.setOnClickListener(v -> say("آپ کہیں: یوٹیوب کھولو، واٹس ایپ کھولو، کروم کھولو، یا فون سیٹنگز کھولو۔"));
        root.addView(help, fullWidth(58));

        TextView note = new TextView(this);
        note.setText("ابھی مائیک بٹن دبانے کے بعد آواز سنی جاتی ہے۔ خودکار پس منظر میں مسلسل سننا اس ابتدائی ورژن میں شامل نہیں۔");
        note.setTextColor(0xFF9DB9DA);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        note.setPadding(8, 28, 8, 8);
        root.addView(note, fullWidth(110));

        setContentView(root);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        } else {
            startGreetingWhenReady();
        }
    }

    private void startGreetingWhenReady() {
        if (!ttsReady || greetingStarted ||
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        greetingStarted = true;
        String greeting = "السلام علیکم! میں عبدالمعید ہوں، آپ کا کیا حکم ہے؟";
        status.setText(greeting);
        tts.setOnUtteranceProgressListener(new android.speech.tts.UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) {
                runOnUiThread(() -> {
                    if (!isFinishing()) listen();
                });
            }
            @Override public void onError(String id) {
                runOnUiThread(() -> { if (!isFinishing()) listen(); });
            }
        });
        tts.speak(greeting, TextToSpeech.QUEUE_FLUSH, null, "startup_greeting");
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startGreetingWhenReady();
        } else if (requestCode == REQ_AUDIO) {
            status.setText("مائیک کی اجازت دیں تاکہ میں آپ کی آواز سن سکوں۔");
        }
    }

    private LinearLayout.LayoutParams fullWidth(int height) {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF24558A));
        LinearLayout.LayoutParams p = fullWidth(58);
        p.setMargins(0, 9, 0, 9);
        b.setLayoutParams(p);
        return b;
    }

    private void listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Abdul Moeed AI کو حکم دیں");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (Exception e) { say("آپ کے فون میں آواز پہچاننے کی سہولت دستیاب نہیں۔"); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                String command = results.get(0);
                status.setText("آپ نے کہا: " + command);
                handleCommand(command);
            }
        }
    }

    private void handleCommand(String raw) {
        String c = raw.toLowerCase(Locale.ROOT);
        if (containsAny(c, "واٹس ایپ", "whatsapp")) {
            openApp("com.whatsapp", "واٹس ایپ نہیں ملی۔");
        } else if (containsAny(c, "یوٹیوب", "youtube")) {
            openApp("com.google.android.youtube", "یوٹیوب نہیں ملی۔");
        } else if (containsAny(c, "کروم", "chrome", "براؤزر")) {
            openApp("com.android.chrome", "کروم نہیں ملا۔");
        } else if (containsAny(c, "سیٹنگ", "settings", "ترتیبات")) {
            say("موبائل سیٹنگز کھول رہا ہوں۔");
            startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));
        } else if (containsAny(c, "کال", "فون ملاؤ", "call")) {
            say("کال کرنے کے لیے فون ایپ کھول رہا ہوں۔ آپ نمبر منتخب کرکے خود کال کریں۔");
            startActivity(new Intent(Intent.ACTION_DIAL));
        } else if (containsAny(c, "وائی فائی", "wifi")) {
            say("وائی فائی کی سیٹنگز کھول رہا ہوں۔");
            startActivity(new Intent(android.provider.Settings.ACTION_WIFI_SETTINGS));
        } else if (containsAny(c, "بلوٹوتھ", "bluetooth")) {
            say("بلوٹوتھ کی سیٹنگز کھول رہا ہوں۔");
            startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
        } else if (containsAny(c, "السلام علیکم", "سلام")) {
            say("وعلیکم السلام! میں عبدالمعید ہوں۔ بتائیں کیا کام ہے؟");
        } else {
            say("معاف کیجیے، یہ حکم ابھی میرے پہلے ورژن میں شامل نہیں۔");
        }
    }

    private boolean containsAny(String text, String... words) {
        for (String w : words) if (text.contains(w)) return true;
        return false;
    }

    private void openApp(String pkg, String error) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) {
            say("ایپ کھول رہا ہوں۔");
            startActivity(launch);
        } else say(error);
    }

    private void say(String text) {
        status.setText(text);
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "abdul_moeed");
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
