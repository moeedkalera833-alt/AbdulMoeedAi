package com.abdulmoeed.assistant;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/*
 * Starter service only. It is not used to secretly monitor the phone.
 * Future navigation actions should be added only after clear user commands
 * and with Android's accessibility disclosure and user-enabled permission.
 */
public class VoiceAccessibilityService extends AccessibilityService {
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // Reserved for explicitly requested, user-visible navigation features.
    }
    @Override public void onInterrupt() { }
}
